# Course Store Template

Template for Django course
