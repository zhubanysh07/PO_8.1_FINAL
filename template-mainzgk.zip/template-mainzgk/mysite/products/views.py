from django.shortcuts import render, get_object_or_404
from .models import Product

def products_list(request):
    # Fetch all products from the database
    items = Product.objects.all()
    # Pass the products to the template
    return render(request, 'products/products.html', {'products': items})

def index(request):
    return render(request, 'products/index.html')




def product_detail(request, pk):
    # Fetch a product by primary key (ID), or return 404 if not found
    item = get_object_or_404(Product, pk=pk)
    # Render the detail template and pass the product
    return render(request, 'products/detail.html', {'product': item})
