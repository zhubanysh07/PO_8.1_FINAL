from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),                  # Homepage
    path('products/', views.products_list, name='products'),  # Products list
    path('products/<int:pk>/', views.product_detail, name='product_detail'),  # Product detail
]
